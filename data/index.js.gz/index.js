window.addEventListener("load", (event) => {
  fetch("/gettimes")
    .then((response) => response.json())
    .then((res) => {
      for (let index = 0; index < 8; index++) {
        let isEnabled = res[index][6] == "1";
        let value = res[index].substring(0, 5);
        $(`#clock-${index + 1}`).val(value);
        $(`#checkbox-${index + 1}`).prop("checked", isEnabled);
      }
    });
  $("#turIleri").on("click", () => {
    fetch("/turIleri");
  });
  $("#turGeri").on("click", () => {
    fetch("/turGeri");
  });

  $("#gecikme").on("click", () => {
    var sure = $("#geriSure").val();
    var ilerisure = $("#ilerisure").val();
    var gecikme = $("#gecikmeVal").val();

    var xhr = new XMLHttpRequest();
    xhr.open(
      "POST",
      `/manualmode?sure=${sure}&ilerisure=${ilerisure}&gecikme=${gecikme}`,
      true
    );
    xhr.send();
  });

  $("#savemodes").on("click", () => {
    var first = $("#1modeaktifinput").val();
    var second = $("#2modeaktifinput").val();
    var wintermode = $("#modewinter")[0].checked ? 1 : 0;
    var xhr = new XMLHttpRequest();
    xhr.open(
      "POST",
      `/wintermode?winter=${wintermode}&mode1=${first}&mode2=${second}`,
      true
    );
    xhr.send();
  });

  fetch("/winterstatus")
    .then((response) => response.json())
    .then((res) => {
      let kis = res["kismodu"] == "1";
      let bir = res["birinci"];
      let iki = res["ikinci"];
      let ileri = res["ileri"];
      let geri = res["geri"];
      let gecikme = res["gecikme"];
      $(`#modeaktif`).val(kis);
      $(`#1modeaktifinput`).val(bir);
      $(`#2modeaktifinput`).val(iki);
      $(`#ilerisure`).val(ileri);
      $(`#geriSure`).val(geri);
      $(`#gecikmeVal`).val(gecikme);
      $(`#modewinter`).prop("checked", kis);
    });

  $("#time-save").on("click", () => {
    let data = [];
    for (let index = 0; index < 8; index++) {
      const element = $(`#clock-${index + 1}`);
      const checkBox = $(`#checkbox-${index + 1}`)[0];
      let clock = element.val().split(":");
      let hours = Number(clock[0]);
      let minutes = Number(clock[1]);
      data.push([hours, minutes, checkBox.checked ? 1 : 0]);
    }
    timeSet(JSON.stringify(data));
  });
  setInterval(() => {
    fetch("/status")
      .then((response) => response.json())
      .then((stats) => {
        let { volt, amp, status } = stats;
        $(`#statustext`).text(status);
        let voltage = $("#voltage");
        voltage.text(volt + "V");
        if (Number(volt) > 22 && Number(volt) < 27) {
          voltage.addClass("text-success");
          voltage.removeClass("text-warning");
          voltage.removeClass("text-danger");
        } else if (Number(volt) > 30 || Number(volt) < 20) {
          voltage.addClass("text-danger");
          voltage.removeClass("text-success");
          voltage.removeClass("text-warning");
        } else {
          voltage.addClass("text-warning");
          voltage.removeClass("text-success");
          voltage.removeClass("text-danger");
        }

        let amper = $("#amper");
        amper.text(amp + "A");
        if (Number(amp) < 10 && Number(amp) > 0) {
          amper.addClass("text-success");
          amper.removeClass("text-warning");
          amper.removeClass("text-danger");
        } else if (Number(amp) > 10 || Number(amp) < 13) {
          amper.addClass("text-warning");
          amper.removeClass("text-success");
          amper.removeClass("text-danger");
        } else {
          amper.addClass("text-danger");
          amper.removeClass("text-success");
          amper.removeClass("text-warning");
        }
      });
  }, 2000);
});
