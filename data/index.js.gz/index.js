const express = require("express");
const path = require("path");
const app = express();
const port = 3000;

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "/index.html"));
});

app.get("/gettimes", (req, res) => {
  res.send(
    200,
    JSON.stringify([
      "01:00,1",
      "02:00,0",
      "03:00,1",
      "04:00,1",
      "05:00,1",
      "12:00,1",
      "12:15,1",
      "19:30,1",
    ])
  );
});

app.get("/status", (req, res) => {
  let volt = Math.floor(Math.random() * 30);
  let amp = Math.floor(Math.random() * 17);
  let status = ["Sarj Oluyor", "Beklemede", "Turda"][
    Math.floor(Math.random() * 3)
  ];
  res.send(200, JSON.stringify({ volt, amp, status }));
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
